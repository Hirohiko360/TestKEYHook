TestKEYHook一款简易通用的鼠标下压及其扩展软件
使用教程：用记事本打开TestKEYHook.bat
修改 cd F:\modtest\TestKEYHook\src为cd 本文件夹根目录
双击TestKEYHook.bat打开窗口即可

具体功能查看程序输出

功能1与功能2分别匹配全自动与半自动的区别

注意：您至少需要安装java和配置环境变量
不同版本,操作系统的电脑对路径的处理可能不同
如果出现找不到或无法加载主类的情况请使用完整开发路径的项目文件
（https://github.com/Hirohiko360/TestKEYHook）下载
然后进入F:\modtest\TestKEYHook\out\production/TestKEYHook中启动

开发来自yby360

